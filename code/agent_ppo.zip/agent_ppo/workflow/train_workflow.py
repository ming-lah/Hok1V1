#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""

import os
import time
import random
from agent_ppo.feature.definition import (
    sample_process,
    build_frame,
    FrameCollector,
    NONE_ACTION,
)
from kaiwu_agent.utils.common_func import attached
from agent_ppo.conf.conf import GameConfig
from tools.env_conf_manager import EnvConfManager
from tools.model_pool_utils import get_valid_model_pool
from tools.metrics_utils import get_training_metrics


@attached
def workflow(envs, agents, logger=None, monitor=None, *args, **kwargs):
    # Whether the agent is training, corresponding to do_predicts
    # 智能体是否进行训练
    do_learns = [True, True]
    last_save_model_time = time.time()

    # Create environment configuration manager instance
    # 创建对局配置管理器实例
    env_conf_manager = EnvConfManager(
        config_path="agent_ppo/conf/train_env_conf.toml",
        logger=logger,
    )

    # Create EpisodeRunner instance
    # 创建 EpisodeRunner 实例
    episode_runner = EpisodeRunner(
        env=envs[0],
        agents=agents,
        logger=logger,
        monitor=monitor,
        env_conf_manager=env_conf_manager,
    )

    while True:
        # Run episodes and collect data
        # 运行对局并收集数据
        for g_data in episode_runner.run_episodes():
            for index, (d_learn, agent) in enumerate(zip(do_learns, agents)):
                if d_learn and len(g_data[index]) > 0:
                    # The learner trains in a while true loop, here learn actually sends samples
                    # learner 采用 while true 训练，此处 learn 实际为发送样本
                    agent.learn(g_data[index])
            g_data.clear()

            now = time.time()
            if now - last_save_model_time > GameConfig.MODEL_SAVE_INTERVAL:
                agents[0].save_model()
                last_save_model_time = now


class EpisodeRunner:
    def __init__(self, env, agents, logger, monitor, env_conf_manager):
        self.env = env
        self.agents = agents
        self.logger = logger
        self.monitor = monitor
        self.env_conf_manager = env_conf_manager
        self.agent_num = len(agents)
        self.episode_cnt = 0
        self.predict_success_count = 0
        self.load_model_success_count = 0
        self.last_report_monitor_time = 0

        # ===== BuffId 监控：去重与节流 =====
        self._last_buff_ids_main = set()
        self._last_buff_ids_enemy = set()
        self._buff_heartbeat = 30   # 每隔多少帧也上报一次（0=仅变化时上报）
        self._frame_tick = 0
        self._buff_slots_k = 8      # 固定上报前 K 个 ID，Prometheus 友好

    # -------- BuffId 提取与上报工具 --------
    # def _collect_buff_ids_from_unit(self, unit: dict) -> set:
    #     """从一个 hero unit 提取 buff configId（若无 config_id 则退化用 buff_id）"""
    #     ids = set()
    #     bs = (unit or {}).get("buff_state", {}) or {}
    #     for m in bs.get("buff_marks", []) or []:
    #         cid = m.get("config_id", m.get("buff_id"))
    #         try:
    #             if cid is not None:
    #                 ids.add(int(cid))
    #         except Exception:
    #             pass
    #     for s in bs.get("buff_skills", []) or []:
    #         cid = s.get("config_id", s.get("buff_id"))
    #         try:
    #             if cid is not None:
    #                 ids.add(int(cid))
    #         except Exception:
    #             pass
    #     return ids
    
    def _collect_buff_ids_from_unit(self, unit: dict) -> set:
        """
        从一个 hero unit 提取 buff 的“配置 id”：
        - 数据协议：BuffMarkState/BuffSkillState 使用 configId（驼峰）
        - 兼容其它可能的命名：config_id / buffId / buff_id / id
        """
        ids = set()
        bs = (unit or {}).get("buff_state") or {}
        if not isinstance(bs, dict):
            return ids

        def read_id(obj: dict):
            for k in ("configId", "config_id", "buffId", "buff_id", "id"):
                if k in obj and obj[k] is not None:
                    try:
                        return int(obj[k])
                    except Exception:
                        pass
            return None

        # 协议：buff_marks / buff_skills（下划线），这里也做一下大小写兜底
        marks = bs.get("buff_marks") or bs.get("buffMarks") or []
        skills = bs.get("buff_skills") or bs.get("buffSkills") or []

        for m in marks:
            cid = read_id(m)  # 优先 configId
            if cid is not None:
                ids.add(cid)
        for s in skills:
            cid = read_id(s)
            if cid is not None:
                ids.add(cid)
        return ids
    

    def _extract_main_enemy_hero(self, frame_state: dict, my_camp_num: int):
        """
        返回 (main_hero, enemy_hero)，兼容 hero_states / npc_states 两种形态
        my_camp_num: 我方阵营号（1 或 2）
        """
        def _camp_num(c):
            # 支持 'PLAYERCAMP_1' / 1 / '1'
            try:
                if isinstance(c, str):
                    import re
                    m = re.search(r'(\d+)$', c)
                    if m:
                        return int(m.group(1))
                return int(c)
            except Exception:
                return -1

        heros = []
        if "hero_states" in (frame_state or {}):
            heros = list(frame_state["hero_states"])
        else:
            for x in (frame_state or {}).get("npc_states", []) or []:
                if x.get("sub_type") == "ACTOR_SUB_hero":
                    # 尽量与 hero_states 对齐，补个 actor_state 壳
                    st = {"actor_state": {"camp": x.get("camp"),
                                          "runtime_id": x.get("runtime_id"),
                                          "config_id": x.get("config_id")}}
                    st.update(x)
                    heros.append(st)

        main_hero, enemy_hero = None, None
        for h in heros:
            camp = ((h.get("actor_state") or {}).get("camp"))
            if _camp_num(camp) == my_camp_num and main_hero is None:
                main_hero = h
            elif enemy_hero is None:
                enemy_hero = h
        return main_hero, enemy_hero

    def _monitor_buff_ids(self, frame_state: dict, my_camp_num: int, monitor_side: int):
        """
        仅上报“数值可视化友好”的字段，避免 Prometheus 报错：
          - buff_main_cnt / buff_enemy_cnt          : 数量
          - buff_main_hash / buff_enemy_hash        : 简单哈希（sum & xor）
          - buff_main_id_1..K / buff_enemy_id_1..K  : 前 K 个 ID（不足用 -1 补齐）
          - buff_ids_side                           : 当前监控侧
        同时把原始列表 print() 到终端，供开发者直接阅读。
        """
        self._frame_tick += 1
        main_hero, enemy_hero = self._extract_main_enemy_hero(frame_state, my_camp_num)
        if not (main_hero and enemy_hero):
            return  # 一方缺失（死亡/初始化等），不上报

        main_ids = self._collect_buff_ids_from_unit(main_hero)
        enemy_ids = self._collect_buff_ids_from_unit(enemy_hero)

        changed = (main_ids != self._last_buff_ids_main) or (enemy_ids != self._last_buff_ids_enemy)
        heartbeat = (self._buff_heartbeat > 0 and (self._frame_tick % self._buff_heartbeat == 0))
        if not (changed or heartbeat):
            return

        # 更新缓存
        self._last_buff_ids_main = main_ids
        self._last_buff_ids_enemy = enemy_ids

        # 数值摘要
        def _hash(ids: set) -> float:
            if not ids:
                return 0.0
            s = sum(int(x) & 0xffffffff for x in ids)
            xr = 0
            for x in ids:
                xr ^= (int(x) & 0xffff)
            return float((s & 0xffffffff) ^ xr)

        def _fixed_slots(ids: set, k: int) -> list:
            arr = sorted([int(x) for x in ids])
            if len(arr) >= k:
                arr = arr[:k]
            else:
                arr = arr + ([-1] * (k - len(arr)))
            return arr

        K = int(self._buff_slots_k)
        m_cnt, e_cnt = len(main_ids), len(enemy_ids)
        m_hash, e_hash = _hash(main_ids), _hash(enemy_ids)
        m_slots = _fixed_slots(main_ids, K)
        e_slots = _fixed_slots(enemy_ids, K)

        # 组装“全数值”监控数据（Prometheus 友好）
        monitor_data = {
            "buff_main_cnt": float(m_cnt),
            "buff_main_hash": float(m_hash),
            "buff_enemy_cnt": float(e_cnt),
            "buff_enemy_hash": float(e_hash),
            "buff_ids_side": float(monitor_side),
        }
        for i, v in enumerate(m_slots, 1):
            monitor_data[f"buff_main_id_{i}"] = float(v)
        for i, v in enumerate(e_slots, 1):
            monitor_data[f"buff_enemy_id_{i}"] = float(v)

        # 发给 monitor
        try:
            if self.monitor:
                self.monitor.put_data({os.getpid(): monitor_data})
        except Exception:
            print("*****************")
            # 监控异常不影响训练
            pass

        # 另外把“原始列表”打印到 stdout，方便在终端直接看（不走 Prometheus）
        try:
            pretty_main = "[" + ", ".join(str(x) for x in sorted(main_ids)) + "]"
            pretty_enemy = "[" + ", ".join(str(x) for x in sorted(enemy_ids)) + "]"
            msg = f"[BUFF-DISCOVERY] main={pretty_main}  enemy={pretty_enemy}"
            if self.logger:
                self.logger.info(msg)
            else:
                print(msg)
        except Exception:
            pass

    def run_episodes(self):
        # Single environment process
        # 单局流程
        while True:
            # Retrieving training metrics
            # 获取训练中的指标
            training_metrics = get_training_metrics()
            if training_metrics:
                for key, value in training_metrics.items():
                    if key == "env":
                        for env_key, env_value in value.items():
                            self.logger.info(f"training_metrics {key} {env_key} is {env_value}")
                    else:
                        self.logger.info(f"training_metrics {key} is {value}")

            # Update environment configuration
            # Can use a list of length 2 to pass in the lineup id of the current game
            # 更新对局配置, 可以用长度为2的列表传入当前对局的阵容id
            usr_conf, is_eval, monitor_side = self.env_conf_manager.update_config()

            # Start a new environment
            # 启动新对局，返回初始环境状态
            observation, extra_info = self.env.reset(usr_conf=usr_conf)
            # Disaster recovery
            # 容灾
            if self._handle_disaster_recovery(extra_info):
                break

            # Reset agents
            # 重置智能体
            self.reset_agents(observation)

            # Reset environment frame collector
            # 重置环境帧收集器
            frame_collector = FrameCollector(self.agent_num)

            # Game variables
            # 对局变量
            self.episode_cnt += 1
            frame_no = 0
            reward_sum_list = [0] * self.agent_num
            is_train_test = os.environ.get("is_train_test", "False").lower() == "true"
            self.logger.info(f"Episode {self.episode_cnt} start, usr_conf is {usr_conf}")

            # Reward initialization
            # 回报初始化
            for i, (do_sample, agent) in enumerate(zip(self.do_samples, self.agents)):
                if do_sample:
                    reward = agent.reward_manager.result(observation[i]["frame_state"])
                    observation[i]["reward"] = reward
                    reward_sum_list[i] += reward["reward_sum"]

            while True:
                # Initialize the default actions. If the agent does not make a decision, env.step uses the default action.
                # 初始化默认的actions，如果智能体不进行决策，则env.step使用默认action
                actions = [NONE_ACTION] * self.agent_num

                for index, (do_predict, do_sample, agent) in enumerate(
                    zip(self.do_predicts, self.do_samples, self.agents)
                ):
                    if do_predict:
                        if not is_eval:
                            actions[index] = agent.predict(observation[index])
                        else:
                            actions[index] = agent.exploit(observation[index])
                        self.predict_success_count += 1

                        # Only sample when do_sample=True and is_eval=False
                        # 评估对局数据不采样，不是训练中最新模型产生的数据不采样
                        if not is_eval and do_sample:
                            frame = build_frame(agent, observation[index])
                            frame_collector.save_frame(frame, agent_id=index)

                # Step forward
                # 推进环境到下一帧，得到新的状态
                frame_no, observation, terminated, truncated, extra_info = self.env.step(actions)
                # Disaster recovery
                # 容灾
                if self._handle_disaster_recovery(extra_info):
                    break

                # Reward generation
                # 计算回报，作为当前环境状态observation的一部分
                for i, (do_sample, agent) in enumerate(zip(self.do_samples, self.agents)):
                    if do_sample:
                        reward = agent.reward_manager.result(observation[i]["frame_state"])

                        # ===== BuffId 数值上报（Prometheus 友好） =====
                        try:
                            # 以 monitor_side 这一侧的 observation 为基准获取我方阵营号（1/2）
                            my_camp_num = int(observation[monitor_side].get("player_camp", 1))
                        except Exception:
                            my_camp_num = 1
                        # 上报（变化或每 N 帧）
                        self._monitor_buff_ids(
                            frame_state=observation[monitor_side].get("frame_state", {}),
                            my_camp_num=my_camp_num,
                            monitor_side=monitor_side
                        )

                        observation[i]["reward"] = reward
                        reward_sum_list[i] += reward["reward_sum"]

                now = time.time()
                if now - self.last_report_monitor_time >= 60:
                    monitor_data = {
                        "actor_predict_succ_cnt": self.predict_success_count,
                        "actor_load_last_model_succ_cnt": self.load_model_success_count,
                    }
                    self.monitor.put_data({os.getpid(): monitor_data})
                    self.last_report_monitor_time = now

                # Normal end or timeout exit, run train_test will exit early
                # 正常结束或超时退出，运行train_test时会提前退出
                is_gameover = terminated or truncated or (is_train_test and frame_no >= 1000)
                if is_gameover:
                    self.logger.info(
                        f"episode_{self.episode_cnt} terminated in fno_{frame_no}, truncated:{truncated}, eval:{is_eval}, reward_sum:{reward_sum_list[monitor_side]}"
                    )
                    # Reward for saving the last state of the environment
                    # 保存环境最后状态的reward
                    for i, (do_sample, agent) in enumerate(zip(self.do_samples, self.agents)):
                        if not is_eval and do_sample:
                            frame_collector.save_last_frame(
                                agent_id=i,
                                reward=observation[i]["reward"]["reward_sum"],
                            )

                    monitor_data = {}
                    if self.monitor and is_eval:
                        monitor_data["reward"] = round(reward_sum_list[monitor_side], 2)
                        self.monitor.put_data({os.getpid(): monitor_data})

                    # Sample process
                    # 进行样本处理，准备训练
                    if len(frame_collector) > 0 and not is_eval:
                        list_agents_samples = sample_process(frame_collector)
                        yield list_agents_samples
                    break

    def reset_agents(self, observation):
        opponent_agent = self.env_conf_manager.get_opponent_agent()
        monitor_side = self.env_conf_manager.get_monitor_side()
        is_train_test = os.environ.get("is_train_test", "False").lower() == "true"

        # The 'do_predicts' specifies which agents are to perform model predictions.
        # do_predicts 指定哪些智能体要进行模型预测
        # The 'do_samples' specifies which agents are to perform training sampling.
        # do_samples 指定哪些智能体要进行训练采样
        self.do_predicts = [True, True]
        self.do_samples = [True, True]

        # Load model according to the configuration
        # 根据对局配置加载模型
        for i, agent in enumerate(self.agents):
            # Report the latest model in the training camp to the monitor
            # 训练中最新模型所在阵营上报监控
            if i == monitor_side:
                # monitor_side uses the latest model
                # monitor_side 使用最新模型
                agent.load_model(id="latest")
            else:
                if opponent_agent == "common_ai":
                    # common_ai does not need to load a model, no need to predict
                    # 如果对手是 common_ai 则不需要加载模型, 也不需要进行预测
                    self.do_predicts[i] = False
                    self.do_samples[i] = False
                elif opponent_agent == "selfplay":
                    # Training model, "latest" - latest model, "random" - random model from the model pool
                    # 加载训练过的模型，可以选择最新模型，也可以选择随机模型 "latest" - 最新模型, "random" - 模型池中随机模型
                    agent.load_model(id="latest")
                    self.load_model_success_count += 1
                else:
                    # Opponent model, model_id is checked from kaiwu.json
                    # 选择kaiwu.json中设置的对手模型, model_id 即 opponent_agent，必须设置正确否则报错
                    eval_candidate_model = get_valid_model_pool(self.logger)
                    if int(opponent_agent) not in eval_candidate_model:
                        raise Exception(f"opponent_agent model_id {opponent_agent} not in {eval_candidate_model}")
                    else:
                        if is_train_test:
                            # Run train_test, cannot get opponent agent, so replace with latest model
                            # 运行 train_test 时, 无法获取到对手模型，因此将替换为最新模型
                            self.logger.info(f"Run train_test, cannot get opponent agent, so replace with latest model")
                            agent.load_model(id="latest")
                        else:
                            agent.load_opponent_agent(id=opponent_agent)
                        self.do_samples[i] = False
            # Reset agent
            # 重置agent
            agent.reset(observation[i])

    def _handle_disaster_recovery(self, extra_info):
        # Handle disaster recovery logic
        # 处理容灾逻辑
        result_code = extra_info.get("result_code", 0)
        result_message = extra_info.get("result_message", "")
        if result_code < 0:
            self.logger.error(f"Env run error, result_code: {result_code}, result_message: {result_message}")
            raise RuntimeError(result_message)
        elif result_code > 0:
            return True
        return False
